//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PlanetSystem.rc
//

#define IDC_SUNS                        10
#define IDC_PLANETS                     11
#define IDC_MAX_MOONS                   12

#define IDC_DELETED_PLANETS             21
#define IDC_DELETED_SUNS                22

#define IDC_NEW_PLANETS                 23
#define IDC_NEW_SUNS                    24

#define IDC_FILENAME                    1000
#define IDM_FILE_NEW                    40001
#define IDM_APP_EXIT                    40002
#define IDM_APP_HELP                    40003
#define IDM_APP_ABOUT                   40004
#define IDM_EDIT_DELETEPLANETORSUN      40005
#define IDM_EDIT_ADDPLANETORSUN         40006

#define IDC_STATIC                      -1
