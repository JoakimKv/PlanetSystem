
/************************************/
/* Namn:	 Joakim Kvistholm		*/
/* Datum:	 2000-08-03				*/
/* Filnamn:	 round.h				*/
/************************************/

/* Indata:								 */
/* Ett flyttal							 */

/* Utdata:								 */
/* Ett avrundat flyttal utan decimaldel  */

/* Beskrivning:							 */ 
/* Avrundar ett flyttal till ett flyttal */
/* (utan decimaldel)					 */

double round( double d ) ;
